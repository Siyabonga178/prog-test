/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class ConsolesSales extends Consoles {
    
    public ConsolesSales(String consoleType,String storeName,double  totalSales){
        super(consoleType, storeName, totalSales);
                
    this.consoleType= consoleType;
    this.storeName = storeName;
    this.totalSales = totalSales;
    
    
    }
    public void printReport(){
        System.out.println("=========================");
        System.out.printf("%25s%n, " + getstoreName());
        System.out.println("Total Sales" + getTotalSales());
        System.out.printf("Console type" getConsoleType());
        System.out.println("===========================");
    }

    private String getTotalSales() {
      
        
    }
    
}
