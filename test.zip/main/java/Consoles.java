/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public abstract class Consoles implements IConsoles {
    //Declaratons
      String consoleType;
    String storeName;
    double  totalSales;
    
    public Consoles(String consoleType,String storeName,double totalSales){
    
    this.consoleType= consoleType;
    this.storeName = storeName;
    this.totalSales = totalSales;
    
}
    public String getConsoleType(){
       return consoleType; 
    }
   public String storeName(){
       return storeName;
   }
   public double  getTotal(){
       return totalSales;
   }
}
