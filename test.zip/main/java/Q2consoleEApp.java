/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.q2consoleeapp;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Q2consoleEApp {

    public static void main(String[] args) {
       Scanner input = new Scanner (System.in);
        System.out.println("Enter consoleType");
        String consoleType = input.nextLine();
        System.out.println("Enter store name");
        String storeName = input.nextLine();
        System.out.println("Enter total amount of sales");
        double totalSales = input.nextInt();
        System.out.println();
    }
}
